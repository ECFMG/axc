# Course catalog search

`GET /api/courses` searches a local sample catalog of twelve courses. The API composition root registers the route with the existing Azure Functions adapter. It requires no external services or production data.

## Query parameters

| Parameter | Values and behavior | Default |
| --- | --- | --- |
| `q` | Case-insensitive substring across title, summary, or any tag. Trimmed; empty text matches all. | All courses |
| `modality` | `online`, `in-person`, `hybrid` (case-sensitive) | All modalities |
| `status` | `draft`, `active`, `retired` (case-sensitive) | All statuses |
| `tag` | Case-insensitive complete tag; surrounding whitespace trimmed; cannot be blank | All tags |
| `page` | Positive decimal safe integer, up to 9007199254740991 | `1` |
| `pageSize` | Positive decimal integer from 1 through 50 | `10` |
| `sort` | `title`, `createdAt`, `updatedAt` | `title` |

Filters combine with AND. Sorting is ascending, using case-insensitive string order for title and ISO timestamp order for dates. Equal sort values use the ID as a deterministic tie-breaker. Pagination follows filtering and sorting. Unknown parameters, repeated parameters, blank enum/numeric values, signs, fractions, and exponent notation return 400.

## Request and success response

```http
GET /api/courses?q=security&modality=online&status=active&tag=ai&page=1&pageSize=1&sort=title
```

HTTP `200`, JSON:

```json
{
  "items": [
    {
      "id": "course-001",
      "title": "AI Security Foundations",
      "summary": "Introductory course on secure AI-assisted development.",
      "modality": "online",
      "status": "active",
      "tags": ["ai", "security"],
      "createdAt": "2026-01-15T00:00:00.000Z",
      "updatedAt": "2026-06-01T00:00:00.000Z"
    }
  ],
  "page": 1,
  "pageSize": 1,
  "totalItems": 2,
  "totalPages": 2
}
```

No matches return `200` with `items: []`, `totalItems: 0`, and `totalPages: 0`, retaining the requested pagination values. A page beyond the last page returns an empty array while retaining the filtered totals.

## Validation error

```http
GET /api/courses?pageSize=51
```

HTTP `400`, JSON:

```json
{
  "error": {
    "code": "INVALID_QUERY_PARAMETER",
    "message": "One or more query parameters are invalid.",
    "details": [
      {
        "field": "pageSize",
        "message": "pageSize must be between 1 and 50."
      }
    ]
  }
}
```

All invalid parameters use this envelope; `details` can contain several field errors.

## Implementation and validation

The application service owns validation and fixture search; Hono maps its typed result to HTTP. Fixtures are read without mutation and returned objects are copied. No dependencies were added. The sample uses an in-memory scan of twelve records; persistent storage is outside this task's scope.

From the repository root, run `pnpm test --env-mode=loose`, `pnpm run lint`, `pnpm run build --env-mode=loose`, `pnpm run typecheck --env-mode=loose`, and `pnpm run test:arch --env-mode=loose`. `pnpm --filter @apps/api test:courses` runs the Azure HTTP integration tests after building; it requires locally installed Azure Functions Core Tools.

import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { after, before, test } from 'node:test';
import { buildApplicationServicesFactory } from '@axc/application-services';
import { createRestApp } from '@axc/rest';

let child;
let base;
let hostOutput = '';
before(
	async () => {
		const server = createServer();
		await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
		const port = server.address().port;
		await new Promise((resolve) => server.close(resolve));
		base = `http://127.0.0.1:${port}`;
		child = spawn(process.execPath, ['--experimental-strip-types', 'scripts/start-host.ts'], {
			cwd: new URL('../', import.meta.url),
			detached: true,
			stdio: ['ignore', 'pipe', 'pipe'],
			env: { ...process.env, PORT: String(port), NODE_ENV: 'test' },
		});
		const capture = (data) => {
			hostOutput = (hostOutput + data.toString()).slice(-10000);
		};
		child.stdout.on('data', capture);
		child.stderr.on('data', capture);
		for (let attempt = 0; attempt < 180; attempt++) {
			if (child.exitCode !== null) throw new Error(hostOutput);
			try {
				const res = await fetch(`${base}/health`, { signal: AbortSignal.timeout(1000) });
				if (res.status === 200) return;
			} catch {
				/* Wait for local Azure host startup. */
			}
			await new Promise((resolve) => setTimeout(resolve, 500));
		}
		throw new Error(`Host startup timed out: ${hostOutput}`);
	},
	{ timeout: 100000 },
);
after(() => {
	if (child?.pid) {
		try {
			process.kill(-child.pid, 'SIGKILL');
		} catch {
			/* Already exited. */
		}
	}
});

test('GET course response and combined filters through Azure registration', async () => {
	const response = await fetch(`${base}/api/courses?q=security&modality=online&status=active&pageSize=5`);
	assert.equal(response.status, 200);
	const body = await response.json();
	assert.deepEqual(
		body.items.map((c) => c.id),
		['course-001', 'course-005'],
	);
	assert.deepEqual([body.page, body.pageSize, body.totalItems, body.totalPages], [1, 5, 2, 1]);
});
test('GET validation response through Azure host', async () => {
	const response = await fetch(`${base}/api/courses?pageSize=51`);
	assert.equal(response.status, 400);
	assert.deepEqual(await response.json(), {
		error: {
			code: 'INVALID_QUERY_PARAMETER',
			message: 'One or more query parameters are invalid.',
			details: [{ field: 'pageSize', message: 'pageSize must be between 1 and 50.' }],
		},
	});
});
test('Hono preserves authorization forwarding for courses and health', async () => {
	const headers = [];
	const factory = buildApplicationServicesFactory({ environment: 'test' });
	const app = createRestApp({
		forRequest: (authorization) => {
			headers.push(authorization);
			return factory.forRequest(authorization);
		},
	});
	for (const path of ['/api/courses', '/health']) {
		assert.equal((await app.request(path, { headers: { Authorization: 'Bearer test-only' } })).status, 200);
	}
	assert.deepEqual(headers, ['Bearer test-only', 'Bearer test-only']);
	assert.equal((await app.request('/api/courses', { method: 'POST' })).status, 404);
});

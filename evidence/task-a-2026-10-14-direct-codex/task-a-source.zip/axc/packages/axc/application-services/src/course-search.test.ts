import { describe, expect, it } from 'vitest';
import { searchCourses } from './course-search.ts';

function search(query = '') {
	const result = searchCourses(new URLSearchParams(query));
	if (!result.ok) throw new Error(JSON.stringify(result.error));
	return result.data;
}

describe('course catalog', () => {
	it('returns the default title-sorted page and independent response objects', () => {
		const page = search();
		expect(page).toMatchObject({ page: 1, pageSize: 10, totalItems: 12, totalPages: 2 });
		expect(page.items).toHaveLength(10);
		expect(page.items.map((c) => c.title.toLowerCase())).toEqual([...page.items.map((c) => c.title.toLowerCase())].sort());
		const first = page.items[0];
		if (!first) throw new Error('Missing fixture');
		first.title = 'changed';
		first.tags.push('changed');
		expect(search().items[0]).not.toEqual(first);
	});
	it('provides the complete model with unique IDs, mixed enums and valid timestamps', () => {
		const items = search('pageSize=50').items;
		expect(new Set(items.map((c) => c.id)).size).toBe(12);
		expect(new Set(items.map((c) => c.modality)).size).toBe(3);
		expect(new Set(items.map((c) => c.status)).size).toBe(3);
		for (const course of items) {
			expect(course.title).not.toBe('');
			expect(course.summary).not.toBe('');
			expect(course.tags.length).toBeGreaterThan(0);
			expect(new Date(course.createdAt).toISOString()).toBe(course.createdAt);
			expect(new Date(course.updatedAt).toISOString()).toBe(course.updatedAt);
		}
	});
	it.each([
		['AI SECURITY FOUNDATIONS', ['course-001']],
		['DISASTER RECOVERY', ['course-002']],
		['GOVERNANCE', ['course-005']],
	])('searches case-insensitively across title, summary and tags: %s', (q, ids) => {
		expect(search(`q=${encodeURIComponent(q)}`).items.map((c) => c.id)).toEqual(ids);
	});
	it.each(['online', 'in-person', 'hybrid'])('filters modality %s', (value) => {
		const items = search(`modality=${value}`).items;
		expect(items.length).toBeGreaterThan(0);
		expect(items.every((c) => c.modality === value)).toBe(true);
	});
	it.each(['draft', 'active', 'retired'])('filters status %s', (value) => {
		const items = search(`status=${value}`).items;
		expect(items.length).toBeGreaterThan(0);
		expect(items.every((c) => c.status === value)).toBe(true);
	});
	it('matches complete tags, case-insensitively', () => {
		expect(search('tag=AI').items.map((c) => c.id)).toEqual(['course-001', 'course-006', 'course-005']);
		expect(search('tag=secur').totalItems).toBe(0);
	});
	it.each([
		['q=SECURITY&modality=online&status=active', ['course-001', 'course-005']],
		['modality=hybrid&status=draft&tag=AI', ['course-006']],
	])('combines all requested filters with AND: %s', (query, ids) => {
		expect(search(query).items.map((c) => c.id)).toEqual(ids);
	});
	it('paginates without gaps or duplicates and retains metadata outside the catalog', () => {
		const all = search('pageSize=50').items;
		const pages = [1, 2, 3].map((p) => search(`page=${p}&pageSize=5`));
		expect(pages.map((p) => p.items.length)).toEqual([5, 5, 2]);
		expect(pages.flatMap((p) => p.items)).toEqual(all);
		expect(pages[1]).toMatchObject({ page: 2, pageSize: 5, totalItems: 12, totalPages: 3 });
		expect(search('page=999999&pageSize=50')).toEqual({ items: [], page: 999999, pageSize: 50, totalItems: 12, totalPages: 1 });
		expect(search('pageSize=1').items).toHaveLength(1);
		expect(search('page=9007199254740991&pageSize=50').items).toEqual([]);
	});
	it.each(['title', 'createdAt', 'updatedAt'] as const)('sorts %s ascending', (sort) => {
		const values = search(`sort=${sort}&pageSize=50`).items.map((c) => c[sort].toLowerCase());
		expect(values).toEqual([...values].sort());
	});
	it.each([
		'modality=invalid',
		'status=invalid',
		'sort=invalid',
		'modality=',
		'status=',
		'sort=',
		'page=0',
		'page=-1',
		'page=1.5',
		'page=bad',
		'page=',
		'page=1e2',
		'page=9007199254740992',
		'pageSize=0',
		'pageSize=51',
		'pageSize=bad',
		'pageSize=1.5',
		'pageSize=',
		'pageSize=+2',
		'tag=',
		'tag=%20',
		'unknown=x',
		'q=a&q=b',
		'page=1&page=2',
	])('rejects invalid input consistently: %s', (query) => {
		const result = searchCourses(new URLSearchParams(query));
		expect(result.ok).toBe(false);
		if (result.ok) throw new Error('Expected validation failure');
		expect(result.error).toMatchObject({ code: 'INVALID_QUERY_PARAMETER', message: 'One or more query parameters are invalid.' });
		expect(result.error.details).toContainEqual({ field: query.split('=')[0], message: expect.any(String) });
	});
	it('aggregates errors and preserves the required pageSize message', () => {
		const result = searchCourses(new URLSearchParams('pageSize=51&status=bad'));
		if (result.ok) throw new Error('Expected validation failure');
		expect(result.error.details).toHaveLength(2);
		expect(result.error.details).toContainEqual({ field: 'pageSize', message: 'pageSize must be between 1 and 50.' });
	});
	it('returns successful empty results and handles empty search text', () => {
		expect(search('q=__missing__')).toEqual({ items: [], page: 1, pageSize: 10, totalItems: 0, totalPages: 0 });
		expect(search('q=')).toEqual(search());
	});
});

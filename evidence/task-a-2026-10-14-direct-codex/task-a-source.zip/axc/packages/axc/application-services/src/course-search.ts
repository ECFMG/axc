import { courseFixtures } from './course-fixtures.ts';
import type { CourseQueryError, CourseSearchResult } from './course-types.ts';

export function searchCourses(params: URLSearchParams): CourseSearchResult {
	const details: CourseQueryError['details'] = [];
	const fields = ['q', 'modality', 'status', 'tag', 'page', 'pageSize', 'sort'];
	for (const field of new Set(params.keys())) {
		if (!fields.includes(field)) details.push({ field, message: 'Unknown query parameter.' });
		else if (params.getAll(field).length !== 1) details.push({ field, message: 'Parameter must be supplied once.' });
	}
	const modality = params.get('modality');
	const status = params.get('status');
	const sort = params.get('sort') ?? 'title';
	if (modality !== null && !['online', 'in-person', 'hybrid'].includes(modality)) details.push({ field: 'modality', message: 'modality must be online, in-person, or hybrid.' });
	if (status !== null && !['draft', 'active', 'retired'].includes(status)) details.push({ field: 'status', message: 'status must be draft, active, or retired.' });
	if (sort !== 'title' && sort !== 'createdAt' && sort !== 'updatedAt') details.push({ field: 'sort', message: 'sort must be title, createdAt, or updatedAt.' });
	const positiveInteger = (field: string, fallback: number, max: number): number => {
		const raw = params.get(field);
		if (raw === null) return fallback;
		const value = Number(raw);
		if (!/^[1-9]\d*$/.test(raw) || !Number.isSafeInteger(value) || value > max) {
			details.push({ field, message: field === 'pageSize' ? 'pageSize must be between 1 and 50.' : 'page must be a positive safe integer.' });
		}
		return value;
	};
	const page = positiveInteger('page', 1, Number.MAX_SAFE_INTEGER);
	const pageSize = positiveInteger('pageSize', 10, 50);
	const tag = params.get('tag')?.trim().toLowerCase();
	if (tag === '') details.push({ field: 'tag', message: 'tag must not be blank.' });
	if (details.length || (sort !== 'title' && sort !== 'createdAt' && sort !== 'updatedAt')) {
		return { ok: false, error: { code: 'INVALID_QUERY_PARAMETER', message: 'One or more query parameters are invalid.', details } };
	}
	const q = params.get('q')?.trim().toLowerCase() ?? '';
	const matches = courseFixtures.filter(
		(course) =>
			(!modality || course.modality === modality) &&
			(!status || course.status === status) &&
			(tag === undefined || course.tags.some((value) => value.toLowerCase() === tag)) &&
			[course.title, course.summary, ...course.tags].some((value) => value.toLowerCase().includes(q)),
	);
	matches.sort((left, right) => {
		const a = left[sort].toLowerCase();
		const b = right[sort].toLowerCase();
		return a < b ? -1 : a > b ? 1 : left.id.localeCompare(right.id);
	});
	const offset = (page - 1) * pageSize;
	return {
		ok: true,
		data: {
			items: matches.slice(offset, offset + pageSize).map((course) => ({ ...course, tags: [...course.tags] })),
			page,
			pageSize,
			totalItems: matches.length,
			totalPages: Math.ceil(matches.length / pageSize),
		},
	};
}

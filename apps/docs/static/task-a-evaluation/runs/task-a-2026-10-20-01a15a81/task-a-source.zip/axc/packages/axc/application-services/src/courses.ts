/** Local catalog read model. No external services are required. */
export interface Course {
	id: string;
	title: string;
	summary: string;
	modality: 'online' | 'in-person' | 'hybrid';
	status: 'draft' | 'active' | 'retired';
	tags: readonly string[];
	createdAt: string;
	updatedAt: string;
}
export interface CourseQuery {
	q?: string;
	modality?: Course['modality'];
	status?: Course['status'];
	tag?: string;
	page: number;
	pageSize: number;
	sort: 'title' | 'createdAt' | 'updatedAt';
}
export interface CoursePage {
	items: readonly Course[];
	page: number;
	pageSize: number;
	totalItems: number;
	totalPages: number;
}

const courses: readonly Course[] = [
	{
		id: 'course-001',
		title: 'AI Security Foundations',
		summary: 'Introductory course on secure AI-assisted development.',
		modality: 'online',
		status: 'active',
		tags: ['ai', 'security'],
		createdAt: '2026-01-01T00:00:00.000Z',
		updatedAt: '2026-06-12T00:00:00.000Z',
	},
	{
		id: 'course-002',
		title: 'Urban Gardening',
		summary: 'Grow herbs and compost in small spaces.',
		modality: 'in-person',
		status: 'active',
		tags: ['sustainability', 'community'],
		createdAt: '2026-01-02T00:00:00.000Z',
		updatedAt: '2026-06-11T00:00:00.000Z',
	},
	{
		id: 'course-003',
		title: 'Web Accessibility',
		summary: 'Build digital experiences for everyone.',
		modality: 'hybrid',
		status: 'active',
		tags: ['design', 'WCAG'],
		createdAt: '2026-01-03T00:00:00.000Z',
		updatedAt: '2026-06-10T00:00:00.000Z',
	},
	{
		id: 'course-004',
		title: 'Pottery Workshop',
		summary: 'Shape clay using hand-building techniques.',
		modality: 'in-person',
		status: 'draft',
		tags: ['art', 'hands-on'],
		createdAt: '2026-01-04T00:00:00.000Z',
		updatedAt: '2026-06-09T00:00:00.000Z',
	},
	{
		id: 'course-005',
		title: 'Data Storytelling',
		summary: 'Turn numerical findings into clear explanations.',
		modality: 'online',
		status: 'active',
		tags: ['data', 'communication'],
		createdAt: '2026-01-05T00:00:00.000Z',
		updatedAt: '2026-06-08T00:00:00.000Z',
	},
	{
		id: 'course-006',
		title: 'Project Leadership',
		summary: 'Coordinate teams and practical delivery plans.',
		modality: 'hybrid',
		status: 'retired',
		tags: ['management', 'communication'],
		createdAt: '2026-01-06T00:00:00.000Z',
		updatedAt: '2026-06-07T00:00:00.000Z',
	},
	{
		id: 'course-007',
		title: 'Conversational Spanish',
		summary: 'Practice everyday dialogue and listening skills.',
		modality: 'in-person',
		status: 'active',
		tags: ['language', 'beginner'],
		createdAt: '2026-01-07T00:00:00.000Z',
		updatedAt: '2026-06-06T00:00:00.000Z',
	},
	{
		id: 'course-008',
		title: 'Cybersecurity Basics',
		summary: 'Recognize threats and protect personal devices.',
		modality: 'online',
		status: 'draft',
		tags: ['security', 'technology'],
		createdAt: '2026-01-08T00:00:00.000Z',
		updatedAt: '2026-06-05T00:00:00.000Z',
	},
	{
		id: 'course-009',
		title: 'Photography Fieldwork',
		summary: 'Explore composition and natural light.',
		modality: 'hybrid',
		status: 'active',
		tags: ['art', 'photography'],
		createdAt: '2026-01-09T00:00:00.000Z',
		updatedAt: '2026-06-04T00:00:00.000Z',
	},
	{
		id: 'course-010',
		title: 'Mindful Movement',
		summary: 'Combine gentle activity with focused breathing.',
		modality: 'in-person',
		status: 'retired',
		tags: ['wellness', 'beginner'],
		createdAt: '2026-01-10T00:00:00.000Z',
		updatedAt: '2026-06-03T00:00:00.000Z',
	},
	{
		id: 'course-011',
		title: 'Python for Analysts',
		summary: 'Analyze tables and automate reports.',
		modality: 'online',
		status: 'active',
		tags: ['data', 'technology'],
		createdAt: '2026-01-11T00:00:00.000Z',
		updatedAt: '2026-06-02T00:00:00.000Z',
	},
	{
		id: 'course-012',
		title: 'Responsible Automation',
		summary: 'Compare security controls for automated systems.',
		modality: 'hybrid',
		status: 'draft',
		tags: ['ai', 'science'],
		createdAt: '2026-01-12T00:00:00.000Z',
		updatedAt: '2026-06-01T00:00:00.000Z',
	},
];
const compare = (a: string, b: string): number => (a < b ? -1 : a > b ? 1 : 0);

export function searchCourses(query: CourseQuery): CoursePage {
	const keyword = query.q?.trim().toLowerCase() ?? '';
	const tag = query.tag?.trim().toLowerCase();
	// ponytail: linear scan suits twelve fixtures; use indexed persistence when the catalog grows.
	const matches = courses.filter(
		(course) =>
			(!query.modality || course.modality === query.modality) &&
			(!query.status || course.status === query.status) &&
			(tag === undefined || course.tags.some((value) => value.toLowerCase() === tag)) &&
			(!keyword || [course.title, course.summary, ...course.tags].some((value) => value.toLowerCase().includes(keyword))),
	);
	matches.sort((a, b) => compare(a[query.sort].toLowerCase(), b[query.sort].toLowerCase()) || compare(a.id, b.id));
	const totalItems = matches.length;
	const totalPages = Math.ceil(totalItems / query.pageSize);
	const start = query.page > totalPages ? totalItems : (query.page - 1) * query.pageSize;
	// Copy nested tags so consumers cannot change the shared fixtures.
	const items = matches.slice(start, start + query.pageSize).map((course) => ({ ...course, tags: [...course.tags] }));
	return { items, page: query.page, pageSize: query.pageSize, totalItems, totalPages };
}

# Course catalog

`GET /api/courses` returns a local training catalog without external services. The twelve fixed fixtures include all modalities and statuses. The endpoint follows the existing anonymous, read-only health route pattern.

## Query parameters

| Parameter | Meaning | Default |
| --- | --- | --- |
| `q` | Case-insensitive substring search across title, summary and tags | No keyword filter |
| `modality` | Exact enum: `online`, `in-person`, `hybrid` | All modalities |
| `status` | Exact enum: `draft`, `active`, `retired` | All statuses |
| `tag` | Case-insensitive exact match against any tag | All tags |
| `page` | Positive safe integer, up to 9007199254740991 | `1` |
| `pageSize` | Integer from 1 through 50 | `10` |
| `sort` | `title`, `createdAt`, or `updatedAt`, ascending | `title` |

Filters combine with AND. Keyword and tag values are trimmed; an empty keyword adds no filter. An empty tag matches no fixtures. Titles sort case-insensitively; equal values use ID as a stable tie-breaker. Dates are ISO strings and sort chronologically. Pagination follows filtering and sorting. A page beyond the last page returns an empty list. Repeated or unknown parameters, empty enum/numeric values, unsafe integers and unsupported enum values return HTTP 400.

## Request

```http
GET /api/courses?q=security&modality=online&status=active&tag=ai&page=1&pageSize=5&sort=title
```

## Success response

HTTP 200, `application/json`:

```json
{
  "items": [{
    "id": "course-001",
    "title": "AI Security Foundations",
    "summary": "Introductory course on secure AI-assisted development.",
    "modality": "online",
    "status": "active",
    "tags": ["ai", "security"],
    "createdAt": "2026-01-01T00:00:00.000Z",
    "updatedAt": "2026-06-12T00:00:00.000Z"
  }],
  "page": 1,
  "pageSize": 5,
  "totalItems": 1,
  "totalPages": 1
}
```

Every course includes the fields above. `totalItems` and `totalPages` describe all filtered results. No matches return HTTP 200 with `items: []`, `totalItems: 0`, and `totalPages: 0`, retaining the requested pagination values.

## Error response

`GET /api/courses?pageSize=51` returns HTTP 400, `application/json`:

```json
{
  "error": {
    "code": "INVALID_QUERY_PARAMETER",
    "message": "One or more query parameters are invalid.",
    "details": [{ "field": "pageSize", "message": "pageSize must be between 1 and 50." }]
  }
}
```

Validation collects all invalid fields before resolving application services. Numeric query values use decimal digits only; fractions, signs, whitespace and exponent syntax are rejected.

## Validation

After installing the existing locked dependencies, run `pnpm run build --env-mode=loose`, `pnpm --filter @apps/api test`, `pnpm test --env-mode=loose`, `pnpm run lint`, `pnpm run typecheck --env-mode=loose`, and `pnpm run test:arch --env-mode=loose` from the repository root. The API tests use the actual composed Hono application and public application-service exports. The existing acceptance runner additionally starts the Azure Functions host.

The fixture catalog is intentional for this sample. Persistence, catalog writes, authentication changes and new dependencies are outside this task.

"""Recover only this task's counters, excluding subsequent follow-up turns."""
import datetime
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
KEYS = ['input_tokens', 'cached_input_tokens', 'output_tokens', 'reasoning_output_tokens', 'total_tokens']


def measure(source_log, turn_id):
    events = [json.loads(line) for line in Path(source_log).read_text().splitlines()]
    start = next(i for i, event in enumerate(events)
                 if event.get('payload', {}).get('type') == 'task_started'
                 and event['payload'].get('turn_id') == turn_id)
    end = next((i for i in range(start + 1, len(events))
                if events[i].get('payload', {}).get('type') == 'task_started'), len(events))
    counters = [(i, event) for i, event in enumerate(events[:end])
                if event.get('payload', {}).get('type') == 'token_count'
                and event['payload'].get('info', {}).get('total_token_usage') is not None]
    prior = [event for i, event in counters if i < start]
    during = [event for i, event in counters if i >= start]
    baseline = prior[-1]['payload']['info']['total_token_usage'] if prior else dict.fromkeys(KEYS, 0)
    latest = during[-1] if during else None
    cumulative = latest['payload']['info']['total_token_usage'] if latest else None
    complete = any(event.get('payload', {}).get('type') in ('task_complete', 'task_completed')
                   and event['payload'].get('turn_id') == turn_id for event in events[start:end])
    finals = [event for event in events[start:end]
              if event.get('payload', {}).get('role') == 'assistant'
              and event['payload'].get('phase') in ('final', 'final_answer')]
    final_accounted = bool(complete and latest and finals and latest['timestamp'] >= finals[-1]['timestamp'])
    return {
        'source_log': source_log, 'turn_id': turn_id,
        'start': {'timestamp': events[start]['timestamp'], 'counters': {k: baseline.get(k) for k in KEYS},
                  'basis': 'Last cumulative snapshot before task_started; zero for a new session.'},
        'end': {'timestamp': latest['timestamp'] if latest else None,
                'counters': {k: cumulative.get(k) for k in KEYS} if cumulative else None,
                'event_ordinal': latest.get('ordinal') if latest else None},
        'measured_usage': {k: cumulative[k] - baseline[k] if cumulative and k in cumulative and k in baseline else None for k in KEYS},
        'complete': final_accounted,
        'missing_usage': [] if final_accounted else ['Original task reporting after latest snapshot, including final assistant response, pending'],
        'missing_counters': [k for k in KEYS if not cumulative or k not in cumulative],
    }


if __name__ == '__main__':
    path = ROOT / 'usage.json'
    record = json.loads(path.read_text())
    main = measure(record['source_log'], record['turn_id'])
    record.update({k: v for k, v in main.items() if k not in ('complete',)})
    for agent in record['subagents']:
        agent.update(measure(agent['source_log'], agent['turn_id']))
    record['aggregate_measured_usage'] = {
        k: sum(actor['measured_usage'][k] for actor in [main] + record['subagents'])
        if all(actor['measured_usage'][k] is not None for actor in [main] + record['subagents']) else None
        for k in KEYS}
    record['complete'] = main['complete'] and all(a['complete'] for a in record['subagents'])
    record['status'] = 'complete' if record['complete'] else 'incomplete'
    record['updated_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record['accounting_notes'] = 'Cumulative ending minus starting counters. Cached input is included in input; reasoning output is included in output. Neither is added twice. Parent and reviewer logs are disjoint. No follow-up turn usage is included.'
    record['label'] = ('Complete original task usage, including final response' if record['complete'] else
                       'recorded usage through ' + str(record['end']['timestamp']) + '; final-response usage pending')
    path.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'label': record['label'], 'primary': record['measured_usage'],
                      'reviewer': [a['measured_usage'] for a in record['subagents']],
                      'aggregate': record['aggregate_measured_usage'], 'complete': record['complete']}, indent=2))

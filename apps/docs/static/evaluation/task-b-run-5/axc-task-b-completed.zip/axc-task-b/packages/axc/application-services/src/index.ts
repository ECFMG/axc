import { createEnrollmentService, type EnrollmentService } from './enrollment-requests.ts';

export type { EnrollmentRequest, EnrollmentStatus, StatusHistoryEntry } from './enrollment-requests.ts';
export { EnrollmentError } from './enrollment-requests.ts';

import { type CoursePage, type CourseQuery, searchCourses } from './courses.ts';

export type { Course, CoursePage, CourseQuery } from './courses.ts';

export const HEALTH_SERVICE_NAME = 'agentCourses-api' as const;
export const HEALTH_PROJECT_CODE = 'axc' as const;

export type HealthEnvironment = 'local' | 'test' | 'production';

export interface HealthStatus {
	status: 'ok';
	service: typeof HEALTH_SERVICE_NAME;
	projectCode: typeof HEALTH_PROJECT_CODE;
	environment: HealthEnvironment;
	timestamp: string;
}

export interface ApiContext {
	environment: HealthEnvironment;
}

export interface ApplicationServices {
	enrollmentRequests: EnrollmentService;
	courses: {
		search(query: CourseQuery): CoursePage;
	};
	health: {
		getStatus(): HealthStatus;
	};
}

export interface ApplicationServicesFactory {
	forRequest(rawAuthHeader?: string): Promise<ApplicationServices>;
}

export function resolveEnvironment(nodeEnv: string | undefined): HealthEnvironment {
	if (nodeEnv === 'production') {
		return 'production';
	}
	if (nodeEnv === 'test') {
		return 'test';
	}
	return 'local';
}

export function buildApplicationServicesFactory(context: ApiContext): ApplicationServicesFactory {
	const enrollmentRequests = createEnrollmentService();
	const forRequest = (): Promise<ApplicationServices> =>
		Promise.resolve({
			courses: { search: searchCourses },
			enrollmentRequests,
			health: {
				getStatus(): HealthStatus {
					return {
						status: 'ok',
						service: HEALTH_SERVICE_NAME,
						projectCode: HEALTH_PROJECT_CODE,
						environment: context.environment,
						timestamp: new Date().toISOString(),
					};
				},
			},
		});

	return { forRequest };
}
